package com.masterwok.opensubtitlesandroid.models


data class QueryParameters(
        val query: String
)