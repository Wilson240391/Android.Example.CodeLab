package com.mhmdawad.torrentmovies.utils

object DeveloperKey {
    const val DEVELOPER_API = "AIzaSyC_oscweLboeE00TTv0w3fYEV5dZyzVenw"
}