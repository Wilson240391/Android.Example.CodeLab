package com.mhmdawad.torrentmovies.utils.rv_listeners


interface QualityListener {

    fun selectQuality(movieUrl: String, movieName:String)
}