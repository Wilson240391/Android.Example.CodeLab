package com.mhmdawad.torrentmovies.utils

interface IOnBackPressed {
    fun onBackPressed(): Boolean
}